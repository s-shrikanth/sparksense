#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// WiFi Credentials
const char* ssid = "Wokwi-WiFi";
const char* password = "any-password";

// MQTT Broker
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

// Pin definitions
#define ONE_WIRE_BUS 15
#define CURRENT_SENSOR_PIN 34
#define HALL_SENSOR_PIN 4

// Sensor objects
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature tempSensor(&oneWire);
Adafruit_MPU6050 mpu;

// Variables for hall sensor RPM
volatile unsigned int hallCount = 0;
unsigned long lastSpeedCalc = 0;
float rpm = 0;

// Machine thresholds
const float MAX_TEMP = 60.0;
const float MAX_ACCEL = 3.0;
const float MAX_CURRENT = 10.0;
const float MAX_RPM = 2000.0;

// Moving average filter for vibration
#define FILTER_SIZE 10
float vibrationBuffer[FILTER_SIZE] = {0};
int vibrationIndex = 0;
float vibrationSum = 0;

void IRAM_ATTR hallSensorISR() {
  hallCount++;
}

// Connect to WiFi with timeout (5 sec)
void setup_wifi() {
  Serial.println();
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  int attempts = 10;
  while (WiFi.status() != WL_CONNECTED && attempts-- > 0) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi connection timed out. Continuing without network.");
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("SparkSenseClient")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

float movingAverage(float newValue) {
  vibrationSum -= vibrationBuffer[vibrationIndex];
  vibrationBuffer[vibrationIndex] = newValue;
  vibrationSum += newValue;
  vibrationIndex = (vibrationIndex + 1) % FILTER_SIZE;
  return vibrationSum / FILTER_SIZE;
}

bool detectFault(float temp, float vib, float curr, float rpm, String &fault) {
  if (temp > MAX_TEMP) {
    fault = "Thermal Fault";
    return true;
  }
  if (vib > MAX_ACCEL) {
    fault = "Vibration Fault";
    return true;
  }
  if (curr > MAX_CURRENT) {
    fault = "Current Overload Fault";
    return true;
  }
  if (rpm > MAX_RPM) {
    fault = "Overspeed Fault";
    return true;
  }
  fault = "";
  return false;
}

void setup() {
  Serial.begin(115200);

  setup_wifi();
  client.setServer(mqtt_server, 1883);

  tempSensor.begin();
  Wire.begin(21, 22);
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 sensor!");
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  pinMode(HALL_SENSOR_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(HALL_SENSOR_PIN), hallSensorISR, RISING);

  Serial.println("SparkSense Enhanced Simulation Started.");
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  tempSensor.requestTemperatures();
  float temperatureC = tempSensor.getTempCByIndex(0);

  sensors_event_t accel, gyro, tempEvt;
  mpu.getEvent(&accel, &gyro, &tempEvt);
  float filteredVibrationX = movingAverage(accel.acceleration.x);

  int adcValue = analogRead(CURRENT_SENSOR_PIN);
  float voltage = adcValue * 3.3 / 4095.0;
  float current = (voltage - 2.5) / 0.185;

  unsigned long now = millis();
  if (now - lastSpeedCalc >= 1000) {
    rpm = hallCount * 60.0;
    hallCount = 0;
    lastSpeedCalc = now;
  }

  Serial.print("Temp(C): ");
  Serial.print(temperatureC);
  Serial.print(", VibX(m/s^2): ");
  Serial.print(filteredVibrationX);
  Serial.print(", Current(A): ");
  Serial.print(current);
  Serial.print(", RPM: ");
  Serial.println(rpm);

  if (temperatureC > 0.95 * MAX_TEMP) Serial.println("WARNING: Temp nearing limit!");
  if (filteredVibrationX > 0.95 * MAX_ACCEL) Serial.println("WARNING: Vibration nearing limit!");
  if (current > 0.95 * MAX_CURRENT) Serial.println("WARNING: Current nearing limit!");
  if (rpm > 0.95 * MAX_RPM) Serial.println("WARNING: RPM nearing limit!");

  String faultType;
  bool faultDetected = detectFault(temperatureC, filteredVibrationX, current, rpm, faultType);

  if (faultDetected) {
    Serial.print("FAULT DETECTED: ");
    Serial.println(faultType);

    if (faultType == "Thermal Fault") Serial.println("SOLUTION: Check cooling system; reduce load.");
    else if (faultType == "Vibration Fault") Serial.println("SOLUTION: Inspect bearings, shaft alignment, mounts.");
    else if (faultType == "Current Overload Fault") Serial.println("SOLUTION: Inspect electrical circuit, reduce load.");
    else if (faultType == "Overspeed Fault") Serial.println("SOLUTION: Adjust speed control; check mechanical load.");

    client.publish("sparksense/alerts", faultType.c_str());
  } else {
    Serial.println("System Normal.");
  }

  char payload[128];
  snprintf(payload, sizeof(payload), "{\"temp\":%.2f,\"vibration\":%.2f,\"current\":%.2f,\"rpm\":%.2f}",
           temperatureC, filteredVibrationX, current, rpm);
  client.publish("sparksense/sensors", payload);

  Serial.println("-------------------------------");
  delay(1000);
}
